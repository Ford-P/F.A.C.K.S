function post(){
    var newEntry= document.getElementById("text").value;
    document.getElementById("entry").innerHTML = document.name.text;
    

}
