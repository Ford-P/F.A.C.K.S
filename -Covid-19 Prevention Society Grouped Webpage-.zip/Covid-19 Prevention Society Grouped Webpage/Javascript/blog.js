function post(){
    var username=document.getElementById("name").value;
    var input=document.getElementById("text").value;
    document.getElementById("user").innerHTML = username;
    document.getElementById("commenText").innerHTML = input;
    
}
